var result = document.getElementById("info");
var guessedNumber = document.getElementById("guessedNumber");
var guessMax = document.getElementById("guessMax");
var guessField = document.getElementById("guessField");
window.onload = function maxGuess() {
    let N = prompt("Please enter the maximum number you want to guess", "Enter a number");
    if (isNaN(N)) {
        alert("It isn't a number.\nPlease enter a number");
        maxGuess();
    }
    else if (N < 1) {
        alert("Please enter a number bigger than 1.");
        document.location.reload();

    }
    else if (N != null && N != "") {

        guessMax.innerHTML = "Maximum number is: 1 - " + Math.floor(N);


        var num = Math.floor(Math.random() * Math.floor(N) + 1);
        console.log(num);

        var guessed = [];

        document.getElementById("submitguess").onclick = function () {


            var gnum = Math.floor(document.getElementById("guessField").value);

            const found = guessed.find(element => element == gnum);  //check if the number is already guessed
            console.log(found);

            if (isNaN(gnum)) {
                alert("That is not a number!");

            }
            else if (gnum < 1) {
                alert("Please enter a number bigger than 1.");

            }
            else if (parseInt(gnum) > parseInt(N)) {
                alert("That number is not in range, try again.");
            }
            else if (found != undefined) {
                alert("You already guessed this number: " + gnum);
            }
            else if (N != null && N != "") {

                if (gnum == num) {
                    guessed.push(gnum);
                    guessedNumber.value = guessed;
                    result.value = "You got it! It took you "
                        + guessed.length + " tries. ";
                }
                else if (gnum > num) {

                    guessed.push(gnum);
                    result.value = ("Sorry! Try a smaller number.")
                    guessField.value = gnum;
                    console.log(guessed);
                }
                else {

                    guessed.push(gnum);
                    result.value = ("Sorry. Try a bigger number.")
                    guessField.value = gnum;
                    console.log(guessed);
                }
            }
        }

    }
};
